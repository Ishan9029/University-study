import React from 'react';
import Fetch from './Fetch';

function App() {
  return (
    <div className="App">
      <h1>Fetch API Example</h1>
      <Fetch />
    </div>
  );
}

export default App;
