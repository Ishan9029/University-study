import React from 'react';
import WelcomeMessage from './WeclomeMessage';

export default function AppWelcome() {
  return (
    <div>
      <WelcomeMessage />
    </div>
  );
}
