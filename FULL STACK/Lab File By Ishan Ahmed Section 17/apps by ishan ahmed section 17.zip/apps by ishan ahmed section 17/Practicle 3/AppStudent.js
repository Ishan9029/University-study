import React from "react";
import Student from "./Student";

export default function App3() {
  return (
    <div>
      <h1>Student List</h1>
      <Student name="Ishan" grade="A" />
      <Student name="Rishabh" grade="B" />
      <Student name="Girish" grade="A" />
      <Student name="Chiranjiv" grade="A" />
    </div>
  );
}
