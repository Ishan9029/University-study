import React from 'react';
export default function About() {
  return <h2>This is the About Page</h2>;
}
