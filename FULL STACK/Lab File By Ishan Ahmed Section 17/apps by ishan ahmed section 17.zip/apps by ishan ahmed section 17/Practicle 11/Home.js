import React from 'react';
export default function Home() {
  return <h2>This is the Home Page</h2>;
}
